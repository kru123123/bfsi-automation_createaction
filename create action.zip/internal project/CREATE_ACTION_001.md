# Test Case Details (CREATE_ACTION_001)

## Test Objective
verify there is on behalf of radio button present and dropdowns are there for on behalf of radio buttons on create action screen. 

## Environment
1.Browser - Chrome, Firefox and Edge  <br>
 

## Pre-conditions
1.System shoud be connected to persistent wifi or if outside then need to connect to VPN<br>
2.Persistent Intranet portal should be open<br> 

## Input data
## Test Steps
| S. No. | Test Steps | Test Data | Expected Result |
| -- | -- | -- | -- |
| 1 |click on create new action tab on the landing page screen||user is on the create action screen|
| 2 |verify there is on behalf of radio button present on the screen||user should able to see on behalf of radio button on screen|
| 3 |verify there is dropdowns for on behalf of radio button on the screen||user should able to see dropdowns for on behalf of radio button on the screen|





