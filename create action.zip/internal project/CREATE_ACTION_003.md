# Test Case Details (CREATE_ACTION_003)

## Test Objective
verify there is description box present on create action screen. 

## Environment
1.Browser - Chrome, Firefox and Edge  <br>
 
## Pre-conditions
1.System shoud be connected to persistent wifi or if outside then need to connect to VPN<br>
2.Persistent Intranet portal should be open<br> 

## Input data
## Test Steps
| S. No. | Test Steps | Test Data | Expected Result |
| -- | -- | -- | -- |
| 1 |click on create new action tab on the landing page screen||user is on the create action screen|
| 2 |verify there is description box present on create action screen||user should able to see there is description box present on create action screen|
| 3 |verify user able to type letters in the description box||user should able to type letters in the description box|



